library(testthat)
library(semmcci)

test_check("semmcci")
