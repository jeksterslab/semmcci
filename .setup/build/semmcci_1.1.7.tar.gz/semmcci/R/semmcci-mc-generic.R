#' Monte Carlo Confidence Intervals (Generic)
#'
#' Calculates Monte Carlo confidence intervals
#' for defined parameters
#' for any fitted model object with `coef` and `vcov` methods.
#'
#' A sampling distribution of parameter estimates is generated
#' from the multivariate normal distribution
#' using the parameter estimates and the sampling variance-covariance matrix.
#' Confidence intervals for defined parameters
#' are generated using the simulated sampling distribution.
#' Parameters are defined using the `def` argument.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details
#' Let \eqn{\hat{\boldsymbol{\theta}}} be the vector of parameter estimates
#' and \eqn{\hat{\boldsymbol{V}}} its sampling covariance matrix,
#' `coef(object)` and `vcov(object)` for the parameters named in `def`.
#' The Monte Carlo draws are
#' \deqn{\hat{\boldsymbol{\theta}}^{\ast}_{r} = \hat{\boldsymbol{\theta}} +
#' \boldsymbol{A}^{\prime} \boldsymbol{z}_{r}, \quad \boldsymbol{z}_{r} \sim
#' \mathcal{N} \left( \boldsymbol{0}, \boldsymbol{I} \right), \quad r = 1,
#' \dots, R,}
#' where \eqn{\boldsymbol{A}^{\prime} \boldsymbol{A} = \hat{\boldsymbol{V}}}.
#' With `decomposition = "eigen"`,
#' \eqn{\hat{\boldsymbol{V}} = \boldsymbol{Q} \boldsymbol{\Lambda}
#' \boldsymbol{Q}^{\prime}} and
#' \eqn{\boldsymbol{A} = \boldsymbol{\Lambda}_{+}^{1 / 2}
#' \boldsymbol{Q}^{\prime}},
#' with negative eigenvalues set to zero;
#' with `decomposition = "chol"`, \eqn{\boldsymbol{A}} is the upper Cholesky
#' factor (the eigenvalue decomposition is used if it fails);
#' `decomposition = "svd"` uses the singular value decomposition.
#' With `pd = TRUE`, the function stops unless every eigenvalue
#' \eqn{\lambda_{l} \geq - \mathrm{tol} \left| \lambda_{1} \right|}.
#' A defined parameter \eqn{\phi = h \left( \boldsymbol{\theta} \right)},
#' given by an expression in `def`,
#' has the draws
#' \eqn{\hat{\phi}^{\ast}_{r} = h \left( \hat{\boldsymbol{\theta}}^{\ast}_{r}
#' \right)}.
#' The confidence intervals are the percentile intervals
#' \eqn{\left[ \hat{G}^{-1} \left( \alpha / 2 \right), \hat{G}^{-1} \left( 1 -
#' \alpha / 2 \right) \right]},
#' where \eqn{\hat{G}} is the empirical distribution function of the draws
#' (Preacher & Selig, 2012).
#'
#' @param object R object.
#'   Fitted model object with `coef` and `vcov` methods
#'   that return a named vector of
#'   estimated parameters and sampling variance-covariance matrix,
#'   respectively.
#' @param def List of character strings.
#'   A list of defined functions of parameters.
#'   The string should be a valid R expression when parsed
#'   and should result a single value when evaluated.
#' @inheritParams MC
#'
#' @return Returns an object of class `semmcci` which is
#'   a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{List of function arguments.}
#'     \item{thetahat}{Parameter estimates \eqn{\hat{\theta}}.}
#'     \item{thetahatstar}{Sampling distribution of parameter estimates
#'                         \eqn{\hat{\theta}^{\ast}}.}
#'     \item{fun}{Function used ("MCGeneric").}
#'   }
#'
#' @examples
#' library(semmcci)
#' library(lavaan)
#'
#' # Data ---------------------------------------------------------------------
#' data("Tal.Or", package = "psych")
#' df <- mice::ampute(Tal.Or)$amp
#'
#' # Monte Carlo --------------------------------------------------------------
#' ## Fit Model in lavaan -----------------------------------------------------
#' model <- "
#'   reaction ~ cp * cond + b * pmi
#'   pmi ~ a * cond
#'   cond ~~ cond
#' "
#' fit <- sem(data = df, model = model, missing = "fiml")
#'
#' ## MCGeneric() -------------------------------------------------------------
#' MCGeneric(
#'   fit,
#'   R = 5L, # use a large value e.g., 20000L for actual research
#'   alpha = 0.05,
#'   def = list(
#'     "a * b",
#'     "cp + (a * b)"
#'   )
#' )
#'
#' @references
#' MacKinnon, D. P., Lockwood, C. M., & Williams, J. (2004).
#' Confidence limits for the indirect effect:
#' Distribution of the product and resampling methods.
#' *Multivariate Behavioral Research*, *39*(1), 99-128.
#' \doi{10.1207/s15327906mbr3901_4}
#'
#' Pesigan, I. J. A., & Cheung, S. F. (2024).
#' Monte Carlo confidence intervals for the indirect effect with missing data.
#' *Behavior Research Methods*.
#' \doi{10.3758/s13428-023-02114-4}
#'
#' Preacher, K. J., & Selig, J. P. (2012).
#' Advantages of Monte Carlo confidence intervals for indirect effects.
#' *Communication Methods and Measures*, *6*(2), 77--98.
#' \doi{10.1080/19312458.2012.679848}
#'
#' @family Monte Carlo in Structural Equation Modeling Functions
#' @keywords semmcci mc
#' @export
MCGeneric <- function(object,
                      def,
                      R = 20000L,
                      alpha = c(0.001, 0.01, 0.05),
                      decomposition = "eigen",
                      pd = TRUE,
                      tol = 1e-06,
                      seed = NULL) {
  args <- list(
    lav = NA,
    R = R,
    alpha = alpha,
    decomposition = decomposition,
    pd = pd,
    tol = tol,
    seed = seed,
    object = object,
    def = def
  )
  # mc
  ## identify coefficients used and do mc only for them
  defs_exp <- lapply(
    X = def,
    FUN = function(x) {
      parse(text = x)
    }
  )
  def_vars <- unique(
    x = unlist(
      x = sapply(
        X = defs_exp, FUN = all.vars
      )
    )
  )
  ## def to be used as names
  def_vec <- def
  dim(x = def_vec) <- NULL
  ## set up Monte Carlo
  if (!is.null(x = seed)) {
    set.seed(seed = seed)
  }
  if (!is.null(x = decomposition)) {
    if (decomposition == "chol") {
      pd <- FALSE
    }
  }
  if (
    inherits(
      x = object,
      what = "lavaan"
    )
  ) {
    location <- lavaan::coef(object = object)[def_vars]
    scale <- lavaan::vcov(object = object)[def_vars, def_vars]
  } else {
    location <- stats::coef(object = object)[def_vars]
    scale <- stats::vcov(object = object)[def_vars, def_vars]
  }
  thetahatstar <- .ThetaHatStar(
    R = R,
    scale = scale,
    location = location,
    decomposition = decomposition,
    pd = pd,
    tol = tol
  )
  ## defined parameters
  ### single replication
  thetahatstar_orig <- thetahatstar$thetahatstar
  var_names <- colnames(x = thetahatstar_orig)
  foo <- function(def,
                  thetahat) {
    names(x = thetahat) <- var_names
    env <- list2env(
      x = as.list(x = thetahat)
    )
    eval(
      expr = parse(text = def),
      envir = env
    )
  }
  ### R replications for 1 def
  bar <- function(def) {
    thetahatstar_dist <- rep(x = NA, times = R)
    for (i in seq_len(length.out = R)) {
      thetahatstar_i <- thetahatstar_orig[i, ]
      thetahatstar_dist[i] <- foo(
        def = def,
        thetahat = thetahatstar_i
      )
    }
    thetahatstar_dist
  }
  ### R replications for all def
  thetahatstar <- do.call(
    what = "cbind",
    args = lapply(
      X = def,
      FUN = bar
    )
  )
  colnames(x = thetahatstar) <- def_vec
  ## estimates
  thetahat <- rep(x = NA, times = length(x = def))
  for (i in seq_along(along.with = thetahat)) {
    thetahat[i] <- foo(
      def = def[[i]],
      thetahat = location
    )
  }
  names(x = thetahat) <- def_vec
  # output
  out <- list(
    call = match.call(),
    args = args,
    thetahat = list(
      est = thetahat
    ),
    thetahatstar = thetahatstar,
    fun = "MCGeneric"
  )
  class(x = out) <- c(
    "semmcci",
    class(x = out)
  )
  out
}
