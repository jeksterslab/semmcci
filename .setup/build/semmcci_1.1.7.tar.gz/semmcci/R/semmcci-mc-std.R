#' Standardized Monte Carlo Confidence Intervals
#'
#' Calculates standardized Monte Carlo confidence intervals
#' for free and defined parameters.
#'
#' The empirical sampling distribution
#' of parameter estimates from the argument `mc` is standardized,
#' that is, each randomly generated vector of parameters is standardized.
#' Defined parameters are computed from the standardized component parameters.
#' Confidence intervals are generated
#' using the standardized empirical sampling distribution.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details
#' Let \eqn{s \left( \boldsymbol{\theta} \right)} map the unstandardized
#' parameters to the completely standardized solution
#' (`lavaan::standardizedSolution(type = "std.all")`):
#' a regression coefficient of \eqn{y} on \eqn{x} becomes
#' \eqn{\beta \, \sigma_{x} / \sigma_{y}} with model-implied standard
#' deviations, a covariance becomes a correlation,
#' and a variance becomes a proportion of the model-implied variance.
#' The standardized draws are
#' \eqn{s \left( \hat{\boldsymbol{\theta}}^{\ast}_{r} \right)},
#' with the draws \eqn{\hat{\boldsymbol{\theta}}^{\ast}_{r}} from `mc`
#' (see [MC()] and [MCMI()]),
#' and a defined parameter
#' \eqn{\phi = h \left( \boldsymbol{\theta} \right)} is computed from the
#' standardized component parameters,
#' \eqn{\hat{\phi}^{\ast}_{r} = h \left( s \left(
#' \hat{\boldsymbol{\theta}}^{\ast}_{r} \right) \right)}.
#' The confidence intervals are the percentile intervals
#' \eqn{\left[ \hat{G}^{-1} \left( \alpha / 2 \right), \hat{G}^{-1} \left( 1 -
#' \alpha / 2 \right) \right]},
#' where \eqn{\hat{G}} is the empirical distribution function of the draws
#' (Preacher & Selig, 2012).
#'
#' @inheritParams MC
#' @param mc Output of the [MC()] or [MCMI()] function.
#'
#' @return Returns an object of class `semmcci` which is
#'   a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{List of function arguments.}
#'     \item{thetahat}{Parameter estimates \eqn{\hat{\theta}}.}
#'     \item{thetahatstar}{Sampling distribution of parameter estimates
#'                         \eqn{\hat{\theta}^{\ast}}.}
#'     \item{fun}{Function used ("MCStd").}
#'   }
#'
#' @examples
#' library(semmcci)
#' library(lavaan)
#'
#' # Data ---------------------------------------------------------------------
#' data("Tal.Or", package = "psych")
#' df <- mice::ampute(Tal.Or)$amp
#'
#' # Monte Carlo --------------------------------------------------------------
#' ## Fit Model in lavaan -----------------------------------------------------
#' model <- "
#'   reaction ~ cp * cond + b * pmi
#'   pmi ~ a * cond
#'   cond ~~ cond
#'   indirect := a * b
#'   direct := cp
#'   total := cp + (a * b)
#' "
#' fit <- sem(data = df, model = model, missing = "fiml")
#'
#' ## MC() --------------------------------------------------------------------
#' unstd <- MC(
#'   fit,
#'   R = 5L, # use a large value e.g., 20000L for actual research
#'   alpha = 0.05
#' )
#'
#' ## Standardized Monte Carlo ------------------------------------------------
#' MCStd(unstd, alpha = 0.05)
#'
#' # Monte Carlo (Multiple Imputation) ----------------------------------------
#' ## Multiple Imputation -----------------------------------------------------
#' mi <- mice::mice(
#'   data = df,
#'   print = FALSE,
#'   m = 5L, # use a large value e.g., 100L for actual research,
#'   seed = 42
#' )
#'
#' ## Fit Model in lavaan -----------------------------------------------------
#' fit <- sem(data = df, model = model) # use default listwise deletion
#'
#' ## MCMI() ------------------------------------------------------------------
#' unstd <- MCMI(
#'   fit,
#'   mi = mi,
#'   R = 5L, # use a large value e.g., 20000L for actual research
#'   alpha = 0.05
#' )
#'
#' ## Standardized Monte Carlo ------------------------------------------------
#' MCStd(unstd, alpha = 0.05)
#'
#' @references
#' Pesigan, I. J. A., & Cheung, S. F. (2024).
#' Monte Carlo confidence intervals for the indirect effect with missing data.
#' *Behavior Research Methods*.
#' \doi{10.3758/s13428-023-02114-4}
#'
#' Preacher, K. J., & Selig, J. P. (2012).
#' Advantages of Monte Carlo confidence intervals for indirect effects.
#' *Communication Methods and Measures*, *6*(2), 77--98.
#' \doi{10.1080/19312458.2012.679848}
#'
#' @family Monte Carlo in Structural Equation Modeling Functions
#' @keywords semmcci mc
#' @export
MCStd <- function(mc,
                  alpha = c(0.001, 0.01, 0.05)) {
  stopifnot(
    inherits(
      x = mc,
      what = "semmcci"
    )
  )
  stopifnot(
    mc$fun %in% c("MC", "MCMI")
  )
  args <- list(
    mc = mc,
    alpha = alpha
  )
  thetahat_std <- as.vector(
    x = lavaan::standardizedSolution(
      object = mc$args$lav,
      type = "std.all",
      se = FALSE,
      zstat = FALSE,
      pvalue = FALSE,
      ci = FALSE,
      remove.eq = FALSE,
      remove.ineq = FALSE,
      remove.def = FALSE
    )[
      ,
      "est.std"
    ]
  )
  names(
    x = thetahat_std
  ) <- colnames(
    x = mc$thetahatstar
  )
  i_free <- mc$args$lav@ParTable$free > 0
  thetahatstar_std <- .MCApply(
    X = mc$thetahatstar[
      ,
      i_free,
      drop = FALSE
    ],
    FUN = function(est) {
      .StdLav(
        est = est,
        object = mc$args$lav
      )
    },
    p = length(
      x = thetahat_std
    )
  )
  colnames(
    x = thetahatstar_std
  ) <- colnames(
    x = mc$thetahatstar
  )
  # remove mean structure
  thetahatstar_std <- thetahatstar_std[
    ,
    which(x = mc$args$lav@ParTable$op != "~1"),
    drop = FALSE
  ]
  out <- list(
    call = match.call(),
    args = args,
    thetahat = .ThetaHat(
      object = mc$args$lav,
      est = thetahat_std
    ),
    thetahatstar = thetahatstar_std,
    fun = "MCStd"
  )
  class(x = out) <- c(
    "semmcci",
    class(x = out)
  )
  out
}
